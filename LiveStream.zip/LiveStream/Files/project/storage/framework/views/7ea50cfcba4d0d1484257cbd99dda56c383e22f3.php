<?php $__env->startSection('content'); ?>

    <section class="go-section">
        <div class="row">
            <div class="container">
                <h2 class="text-center"><?php echo e($pagename); ?></h2>
                <hr>
                <div class="col-md-12 up">
                <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 ftv">
                        <div class="singletv">
                            <a href="<?php echo e(url('/tv')); ?>/<?php echo e($channel->id); ?>">
                                <?php if($channel->live == "yes"): ?>
                                <h5 class="red-break"><i class="fa fa-circle fa-fw"></i>Live</h5>
                                <?php endif; ?>
                                <img src="<?php echo e(url('/assets/images/tv')); ?>/<?php echo e($channel->featured_image); ?>" alt="" class="thumb tvcatumb">

                                <div class="post-content">
                                    <h3><?php echo e($channel->title); ?></h3>
                                </div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>