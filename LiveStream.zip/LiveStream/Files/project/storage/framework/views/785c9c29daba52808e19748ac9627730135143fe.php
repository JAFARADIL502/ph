<?php $__env->startSection('content'); ?>

<section class="home-top">
    <div class="container">
        <div class="row">
            <div class="col-md-9 up">
                <div class="title-section">
                    <h1><span><?php echo e($tvinfo->title); ?></span></h1>
                    <?php if($tvinfo->live == "yes"): ?>
                        <span class="tvlive"><i class="fa fa-circle fa-fw"></i>Live</span>
                    <?php endif; ?>
                </div>
                <div class="showtv">
                    <?php echo $tvinfo->embed; ?>

                </div>

                
                <div class="text-center">
                    <div class="desktop-advert">
                        <?php if(!empty($ads728x90)): ?>
                            <?php if($ads728x90->type == "banner"): ?>
                                <a class="ads" href="<?php echo e($ads728x90->redirect_url); ?>" target="_blank">
                                    <img class="banner-728x90" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads728x90->banner_file); ?>" alt="Advertisement">
                                </a>
                            <?php else: ?>
                                <?php echo $ads728x90->script; ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="descriptions">
                    <h3>Description</h3><hr>
                    <?php echo $tvinfo->description; ?>

                </div>

                <div class="descriptions">
                    <div class="fb-comments" data-width="100%" data-href="<?php echo e(url('/tv')); ?>/<?php echo e($tvinfo->id); ?>" data-numposts="5"></div>
                </div>

            </div>
            <div class="col-md-3 tv-side">
                <div class="sidebar-nav">
                    <div class="tvcats" style="margin-top: 20px">
                        <h3>Categories</h3>
                        <ul class="nav nav-list categories">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url('/channels')); ?>/<?php echo e($category->slug); ?>"> <?php echo e($category->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>


                <div class="text-center">
                    <div class="desktop-advert">
                        <?php if(!empty($ads300x250)): ?>
                            <?php if($ads300x250->type == "banner"): ?>
                                <a class="ads" href="<?php echo e($ads300x250->redirect_url); ?>" target="_blank">
                                    <img class="banner-300x250" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads300x250->banner_file); ?>" alt="Advertisement">
                                </a>
                            <?php else: ?>
                                <?php echo $ads300x250->script; ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="side-socicon text-center">
                    <?php if($sociallinks[0]->f_status == "enable"): ?>
                        <a href="<?php echo e($sociallinks[0]->facebook); ?>" class="facebook"><i class="fa fa-facebook"></i></a>
                    <?php endif; ?>
                    <?php if($sociallinks[0]->t_status == "enable"): ?>
                        <a href="<?php echo e($sociallinks[0]->twiter); ?>" class="twitter"><i class="fa fa-twitter"></i></a>
                    <?php endif; ?>
                    <?php if($sociallinks[0]->g_status == "enable"): ?>
                        <a href="<?php echo e($sociallinks[0]->g_plus); ?>" class="google"><i class="fa fa-google"></i></a>
                    <?php endif; ?>
                    <?php if($sociallinks[0]->link_status == "enable"): ?>
                        <a href="<?php echo e($sociallinks[0]->linkedin); ?>" class="linkedin"><i class="fa fa-linkedin"></i></a>
                    <?php endif; ?>
                </div>

                <div class="text-center">
                    <div class="desktop-advert">
                        <?php if(!empty($ads300x600)): ?>
                            <?php if($ads300x600->type == "banner"): ?>
                                <a class="ads" href="<?php echo e($ads300x600->redirect_url); ?>" target="_blank">
                                    <img class="banner-300x600" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads300x600->banner_file); ?>" alt="Advertisement">
                                </a>
                            <?php else: ?>
                                <?php echo $ads300x600->script; ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>