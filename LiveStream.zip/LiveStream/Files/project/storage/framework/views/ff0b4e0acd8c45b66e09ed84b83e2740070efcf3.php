<?php $__env->startSection('content'); ?>

    <style>

    </style>
<section class="home-top">
    <div class="container">
        <div class="row">
            <div class="col-md-9 up">
                <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 ftv">
                        <div class="singletv">
                            <a href="<?php echo e(url('/tv')); ?>/<?php echo e($channel->id); ?>">
                                <?php if($channel->live == "yes"): ?>
                                    <h5 class="red-break"><i class="fa fa-circle fa-fw"></i>Live</h5>
                                <?php endif; ?>
                                <img src="<?php echo e(url('/assets/images/tv')); ?>/<?php echo e($channel->featured_image); ?>" alt="" class="thumb tvthumb">

                                <div class="post-content">
                                    <h3><?php echo e($channel->title); ?></h3>
                                </div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-3">
                <div class="sidebar-nav">
                    <div class="tvcats">
                        <h3>Categories</h3>
                        <ul class="nav nav-list categories">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(url('/channels')); ?>/<?php echo e($category->slug); ?>"> <?php echo e($category->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="row tvsection">
    <div class="container">
    <hr>
            <div class="col-md-9">
                
                <div class="text-center">
                    <div class="desktop-advert">
                        <?php if(!empty($ads728x90)): ?>
                            <?php if($ads728x90->type == "banner"): ?>
                                <a class="ads" href="<?php echo e($ads728x90->redirect_url); ?>" target="_blank">
                                    <img class="banner-728x90" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads728x90->banner_file); ?>" alt="Advertisement">
                                </a>
                            <?php else: ?>
                                <?php echo $ads728x90->script; ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="wow fadeInUp row">
                        <div class="title-section">
                            <h1><span>Popular Channels</span></h1>
                        </div>
                    <div class="col-md-12" style="padding: 0">
                        <?php $__currentLoopData = $topchannels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 ftv">
                                <div class="singletv">
                                    <a href="<?php echo e(url('/tv')); ?>/<?php echo e($channel->id); ?>">
                                        <?php if($channel->live == "yes"): ?>
                                            <h5 class="red-break"><i class="fa fa-circle fa-fw"></i>Live</h5>
                                        <?php endif; ?>
                                        <img src="<?php echo e(url('/assets/images/tv')); ?>/<?php echo e($channel->featured_image); ?>" alt="" class="thumb tvthumb">

                                        <div class="post-content">
                                            <h3><?php echo e($channel->title); ?></h3>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>

                <div class="wow fadeInUp row">
                        <div class="title-section">
                            <h1><span>Latest Channels</span></h1>
                        </div>
                    <div class="col-md-12" style="padding: 0">
                        <?php $__currentLoopData = $latestchannels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 ftv">
                                <div class="singletv">
                                    <a href="<?php echo e(url('/tv')); ?>/<?php echo e($channel->id); ?>">
                                        <?php if($channel->live == "yes"): ?>
                                            <h5 class="red-break"><i class="fa fa-circle fa-fw"></i>Live</h5>
                                        <?php endif; ?>
                                        <img src="<?php echo e(url('/assets/images/tv')); ?>/<?php echo e($channel->featured_image); ?>" alt="" class="thumb tvthumb">

                                        <div class="post-content">
                                            <h3><?php echo e($channel->title); ?></h3>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>

            </div>


            <div class="col-md-3">
                <div class="text-center">
                    <div class="desktop-advert">
                        <?php if(!empty($ads300x250)): ?>
                            <?php if($ads300x250->type == "banner"): ?>
                                <a class="ads" href="<?php echo e($ads300x250->redirect_url); ?>" target="_blank">
                                    <img class="banner-300x250" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads300x250->banner_file); ?>" alt="Advertisement">
                                </a>
                            <?php else: ?>
                                <?php echo $ads300x250->script; ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="side-socicon text-center">
                    <?php if($sociallinks[0]->f_status == "enable"): ?>
                        <a href="<?php echo e($sociallinks[0]->facebook); ?>" class="facebook"><i class="fa fa-facebook"></i></a>
                    <?php endif; ?>
                    <?php if($sociallinks[0]->t_status == "enable"): ?>
                        <a href="<?php echo e($sociallinks[0]->twiter); ?>" class="twitter"><i class="fa fa-twitter"></i></a>
                    <?php endif; ?>
                    <?php if($sociallinks[0]->g_status == "enable"): ?>
                        <a href="<?php echo e($sociallinks[0]->g_plus); ?>" class="google"><i class="fa fa-google"></i></a>
                    <?php endif; ?>
                    <?php if($sociallinks[0]->link_status == "enable"): ?>
                        <a href="<?php echo e($sociallinks[0]->linkedin); ?>" class="linkedin"><i class="fa fa-linkedin"></i></a>
                    <?php endif; ?>
                </div>


                <div class="text-center">
                    <div class="desktop-advert">
                        <?php if(!empty($ads300x600)): ?>
                            <?php if($ads300x600->type == "banner"): ?>
                                <a class="ads" href="<?php echo e($ads300x600->redirect_url); ?>" target="_blank">
                                    <img class="banner-300x600" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads300x600->banner_file); ?>" alt="Advertisement">
                                </a>
                            <?php else: ?>
                                <?php echo $ads300x600->script; ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

            </div>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>